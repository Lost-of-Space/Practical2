package Files.Entities;

public class File {

  private String fileName;
  private int fileSize;
  private String creationDate;
  private int numberOfAccesses;

  //конструктор
  public File(String fileName, int fileSize, String creationDate, int numberOfAccesses) {
    this.fileName = fileName;
    this.fileSize = fileSize;
    this.creationDate = creationDate;
    this.numberOfAccesses = numberOfAccesses;
  }

  public String getFileName() {
    return fileName;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public int getFileSize() {
    return fileSize;
  }

  public void setFileSize(int fileSize) {
    this.fileSize = fileSize;
  }

  public String getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(String creationDate) {
    this.creationDate = creationDate;
  }

  public int getNumberOfAccesses() {
    return numberOfAccesses;
  }

  public void setNumberOfAccesses(int numberOfAccesses) {
    this.numberOfAccesses = numberOfAccesses;
  }

  //перевизначений метод
  @Override
  public String toString() {
    return "\t> " + fileName + "\n\t\t\tРозмір: " + fileSize + " мгбайт, Створений: " + creationDate
        +
        ", Звернень: " + numberOfAccesses;
  }
}

package Files.Interface;

import Files.Buisnesslogic.FileManager;
import Files.Entities.File;

public class Main {

  public static void main(String[] args) {
    //створення масиву об'єктів класу File
    File[] files = {
        new File("ForzaScreenshots.zip", 23, "18/04/2022", 3),
        new File("Практична 2 звіт.docx", 2, "05/10/2023", 7),
        new File("screenshot_109.jpg", 1, "04/10/2023", 1),
        new File("TheWeeknd_Starboy.mp3", 9, "17/02/2022", 15),
    };

    System.out.println("Всі файли:");
    FileManager.sortByFileName(files);
    for (File file : files) {
      System.out.println(file);
    }

    FileManager.filterBySize(files, 5);

    FileManager.filterByAccessCount(files, 5);
  }
}

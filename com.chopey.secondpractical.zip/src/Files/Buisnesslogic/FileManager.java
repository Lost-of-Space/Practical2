package Files.Buisnesslogic;

import Files.Entities.File;
import java.util.Arrays;
import java.util.Comparator;

public class FileManager {

  //сортування за алфавітом
  public static void sortByFileName(File[] files) {
    Arrays.sort(files, Comparator.comparing(File::getFileName));
  }

  //виведення файлів з перевищенням по розміру
  public static void filterBySize(File[] files, int size) {
    System.out.println("\nФайли з розміром, більшим ніж " + size + " мегабайтів:");
    for (File file : files) {
      if (file.getFileSize() > size) {
        System.out.println(file);
      }
    }
  }

  //виведення файлів з перевищенням числа звернень
  public static void filterByAccessCount(File[] files, int accessCount) {
    System.out.println(
        "\nФайли, кількість звернень до яких перевищує число " + accessCount + ":");
    for (File file : files) {
      if (file.getNumberOfAccesses() > accessCount) {
        System.out.println(file);
      }
    }
  }
}